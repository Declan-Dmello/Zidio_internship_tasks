import pandas as pd
from sklearn.ensemble import IsolationForest
import joblib

# Load and preprocess data
data = pd.read_csv("../data/sample_transaction.csv")
data["timestamp"] = pd.to_datetime(data["timestamp"])
data["hour"] = data["timestamp"].dt.hour
data["dayofweek"] = data["timestamp"].dt.dayofweek
data["customer_id_encoded"] = data["customer_id"].astype("category").cat.codes
data["transaction_count"] = data["customer_id"].map(data["customer_id"].value_counts())

# Features for the model
X = data[["amount", "hour", "dayofweek", "customer_id_encoded", "transaction_count"]]

# Train Isolation Forest
model = IsolationForest(contamination=0.2, random_state=42)
model.fit(X)

# Save the model
joblib.dump(model, "../models/fraud_model.pkl")
print("Model saved to models/fraud_model.pkl")
