from kafka import KafkaConsumer
import json
import smtplib
from email.message import EmailMessage
import logging
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.FileHandler("alerts.log"), logging.StreamHandler()]
)

# Initialize Kafka consumer
consumer = KafkaConsumer(
    'transactions',
    bootstrap_servers=['localhost:9092'],
    value_deserializer=lambda m: json.loads(m.decode('utf-8')),
    auto_offset_reset='latest',
    group_id='fraud-alert-system'
)

# Email configuration - replace with your actual email settings
EMAIL_CONFIG = {
    'enabled': False,  # Set to True to enable email alerts
    'smtp_server': 'smtp.gmail.com',
    'smtp_port': 587,
    'username': 'your_email@gmail.com',
    'password': 'your_app_password',  # Use app password for Gmail
    'recipient': 'alerts@example.com'
}


def send_email_alert(transaction):
    """Send email alert for fraudulent transaction"""
    if not EMAIL_CONFIG['enabled']:
        logging.info("Email alerts disabled. Would have sent alert for: " +
                     f"Transaction {transaction['transaction_id']}")
        return

    try:
        msg = EmailMessage()
        msg['Subject'] = f"FRAUD ALERT: Transaction {transaction['transaction_id']}"
        msg['From'] = EMAIL_CONFIG['username']
        msg['To'] = EMAIL_CONFIG['recipient']

        # Create email content
        email_content = f"""
        FRAUD ALERT!

        Transaction ID: {transaction['transaction_id']}
        Amount: ${transaction['amount']}
        Customer: {transaction['customer_id']}
        Time: {transaction['timestamp']}

        This transaction has been flagged as potentially fraudulent.
        Please review immediately.
        """

        msg.set_content(email_content)

        # Send email
        with smtplib.SMTP(EMAIL_CONFIG['smtp_server'], EMAIL_CONFIG['smtp_port']) as server:
            server.starttls()
            server.login(EMAIL_CONFIG['username'], EMAIL_CONFIG['password'])
            server.send_message(msg)

        logging.info(f"Email alert sent for transaction {transaction['transaction_id']}")
    except Exception as e:
        logging.error(f"Failed to send email alert: {str(e)}")


def is_suspicious(transaction):
    """Simple fraud detection logic"""
    # Suspicious if amount > $1000 or specific flagged customers
    return transaction['amount'] > 1000 or transaction['customer_id'] in ['C101', 'C103']


def process_transactions():
    """Process incoming transactions and generate alerts for suspicious ones"""
    logging.info("Alert system started. Monitoring for suspicious transactions...")

    try:
        for message in consumer:
            transaction = message.value

            # Check if transaction is suspicious
            if is_suspicious(transaction):
                logging.warning(f"ALERT: Suspicious transaction detected!")
                logging.warning(f"Transaction ID: {transaction['transaction_id']}")
                logging.warning(f"Amount: ${transaction['amount']}")
                logging.warning(f"Customer: {transaction['customer_id']}")
                logging.warning(f"Time: {transaction['timestamp']}")

                # Send email alert
                send_email_alert(transaction)

                # Here you could also:
                # - Send SMS alerts
                # - Push notifications to a mobile app
                # - Update a real-time alert dashboard

    except KeyboardInterrupt:
        logging.info("Alert system stopped.")
    finally:
        consumer.close()


if __name__ == "__main__":
    process_transactions()