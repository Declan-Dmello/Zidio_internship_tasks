from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col, udf
from pyspark.sql.types import StructType, StringType, DoubleType, BooleanType
import joblib

# Load the trained model
model = joblib.load("../models/fraud_model.pkl")


def predict_fraud(amount, customer_id):
    """Simple fraud prediction based on amount and customer_id"""
    try:
        # Simple logic: flag transactions over $1000 or suspicious customer patterns
        # In real implementation, use your model properly with all needed features
        is_suspicious_customer = customer_id in ["C101", "C103"]  # Example flagged customers
        is_large_amount = amount > 1000.0

        return is_large_amount or is_suspicious_customer
    except:
        return False


# Register UDF
predict_fraud_udf = udf(predict_fraud, BooleanType())

# Initialize Spark
spark = SparkSession.builder \
    .appName("RealTimeFraudDetection") \
    .master("local[*]") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

# Schema - added a few more useful fields
schema = StructType() \
    .add("transaction_id", StringType()) \
    .add("amount", DoubleType()) \
    .add("customer_id", StringType()) \
    .add("timestamp", StringType()) \
    .add("merchant", StringType(), True) \  # Optional fields
.add("category", StringType(), True)

# Kafka read
raw_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "transactions") \
    .option("startingOffsets", "latest") \
    .load()

parsed_df = raw_df.selectExpr("CAST(value AS STRING)") \
    .select(from_json(col("value"), schema).alias("data")) \
    .select("data.*")

# Apply fraud model with both amount and customer_id
fraud_df = parsed_df.withColumn("is_fraud",
                                predict_fraud_udf(col("amount"), col("customer_id")))

# Add a risk score column for better visualization
fraud_df = fraud_df.withColumn("risk_score",
                               when((col("amount") > 1000), 80)
                               .when((col("amount") > 500), 50)
                               .otherwise(20))

# Save flagged data
query = fraud_df.writeStream \
    .outputMode("append") \
    .format("csv") \
    .option("path", "data/fraud_results") \
    .option("checkpointLocation", "data/checkpoints") \
    .start()

# Also store in in-memory table for dashboard queries
query2 = fraud_df.writeStream \
    .outputMode("append") \
    .format("memory") \
    .queryName("live_transactions") \
    .start()

print("Fraud detection started. Press Ctrl+C to stop.")
query.awaitTermination()