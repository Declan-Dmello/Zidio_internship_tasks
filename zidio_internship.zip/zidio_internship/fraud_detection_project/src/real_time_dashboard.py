import streamlit as st
import pandas as pd
import os
import glob
import time
import matplotlib.pyplot as plt
import seaborn as sns

# Page config
st.set_page_config(
    page_title="Fraud Detection Dashboard",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Title and description
st.title("💳 Real-Time Fraud Detection Dashboard")
st.markdown("Monitor transactions and detect fraud in real-time")

# Sidebar controls
st.sidebar.header("Dashboard Controls")
refresh_rate = st.sidebar.slider("Refresh Rate (seconds)", 1, 30, 5)
show_all = st.sidebar.checkbox("Show All Transactions", False)


# Function to load data from CSV files
def load_transaction_data():
    csv_files = glob.glob("data/fraud_results/*.csv")
    if not csv_files:
        return None

    # Get the latest files (up to 5)
    latest_files = sorted(csv_files, key=os.path.getctime, reverse=True)[:5]

    # Read and combine data from these files
    dfs = []
    for file in latest_files:
        try:
            df = pd.read_csv(file, header=None)
            dfs.append(df)
        except:
            pass

    if not dfs:
        return None

    # Combine all dataframes
    combined_df = pd.concat(dfs, ignore_index=True)

    # Add column names
    combined_df.columns = ["transaction_id", "amount", "customer_id", "timestamp",
                           "merchant", "category", "is_fraud", "risk_score"]

    # Convert boolean strings to actual booleans
    combined_df["is_fraud"] = combined_df["is_fraud"].astype(str).map({"true": True, "false": False})

    return combined_df


# Create dashboard layout with two columns
col1, col2 = st.columns([3, 2])

# Main dashboard loop
while True:
    # Load the transaction data
    df = load_transaction_data()

    if df is None:
        st.warning("No data available yet. Please start the producer and consumer.")
        time.sleep(refresh_rate)
        st.experimental_rerun()
        continue

    # Calculate metrics
    total_transactions = len(df)
    fraud_transactions = df["is_fraud"].sum()
    fraud_percentage = round((fraud_transactions / total_transactions) * 100, 2) if total_transactions else 0
    high_risk_count = len(df[df["risk_score"] > 50])

    # Display metrics in the first column
    with col1:
        st.subheader("Transaction Overview")
        metrics_cols = st.columns(3)
        metrics_cols[0].metric("Total Transactions", total_transactions)
        metrics_cols[1].metric("Fraud Detected", fraud_transactions)
        metrics_cols[2].metric("Fraud Rate", f"{fraud_percentage}%")

        # Show only fraudulent transactions by default
        display_df = df if show_all else df[df["is_fraud"] == True]

        st.subheader("Latest Transactions" if show_all else "Flagged Fraudulent Transactions")

        # Style the dataframe with conditional formatting
        st.dataframe(
            display_df.sort_values("timestamp", ascending=False).head(10),
            use_container_width=True,
            height=300
        )

    # Visualizations in the second column
    with col2:
        st.subheader("Transaction Analysis")

        # Bar chart of transaction amounts by fraud status
        fig, ax = plt.subplots(figsize=(8, 5))
        sns.histplot(data=df, x="amount", hue="is_fraud", element="step", bins=10)
        plt.title("Transaction Amounts Distribution")
        plt.xlabel("Amount ($)")
        plt.ylabel("Count")
        st.pyplot(fig)

        # Risk score distribution
        st.subheader("Risk Score Distribution")
        risk_data = df["risk_score"].value_counts().sort_index()
        st.bar_chart(risk_data)

    # Add transaction timeline
    st.subheader("Transaction Timeline")
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df_timeline = df.groupby(pd.Grouper(key="timestamp", freq="1min")).size().reset_index(name="count")
    st.line_chart(df_timeline.set_index("timestamp"))

    # Wait for the specified refresh rate
    time.sleep(refresh_rate)
    st.experimental_rerun()