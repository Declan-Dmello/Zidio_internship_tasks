from kafka import KafkaProducer
import json
import time
import random

# Initialize Kafka producer
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Sample data for generating realistic transactions
customers = ['C101', 'C102', 'C103', 'C104']
merchants = ['Amazon', 'Walmart', 'Target', 'Starbucks', 'Shell', 'Apple Store']
categories = ['Retail', 'Grocery', 'Food', 'Gas', 'Electronics']

print("Starting transaction generator. Press Ctrl+C to stop.")

# Generate and send transactions continuously
try:
    while True:
        # Generate random transaction data
        transaction = {
            "transaction_id": f"T{random.randint(1000, 9999)}",
            "amount": round(random.uniform(10.0, 1500.0), 2),
            "customer_id": random.choice(customers),
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "merchant": random.choice(merchants),
            "category": random.choice(categories)
        }

        # Sometimes generate suspicious transactions (high amount)
        if random.random() < 0.1:  # 10% chance of suspicious transaction
            transaction["amount"] = round(random.uniform(1000.0, 5000.0), 2)

        # Send to Kafka
        producer.send('transactions', value=transaction)
        print(f"Sent: {transaction['transaction_id']} - ${transaction['amount']} - {transaction['customer_id']}")

        # Wait before sending next transaction
        time.sleep(1)
except KeyboardInterrupt:
    print("Transaction generator stopped.")
    producer.close()