import pandas as pd
import numpy as np
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.metrics import classification_report
from xgboost import XGBClassifier
import plotly.express as px
import plotly.figure_factory as ff
import warnings

warnings.filterwarnings('ignore')


# 1. Data Acquisition & Preprocessing
def load_and_preprocess_data(file_path=r'C:\Users\decla\PycharmProjects\pythonProject2\data\creditcard.csv'):
    st.write("Loading and preprocessing data...")
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        st.error(f"Dataset not found at {file_path}. Please ensure the file exists.")
        return None

    # Handle missing values
    df = df.dropna()

    # Feature engineering: Normalize 'Amount' and 'Time'
    scaler = StandardScaler()
    df['Scaled_Amount'] = scaler.fit_transform(df[['Amount']])
    df['Scaled_Time'] = scaler.fit_transform(df[['Time']])

    # Drop original columns
    df = df.drop(['Amount', 'Time'], axis=1)

    st.write("Data preprocessing complete.")
    return df


# 2. Fraud Detection Models
def train_models(X_train, y_train):
    models = {}

    # Logistic Regression
    with st.spinner("Training Logistic Regression..."):
        lr = LogisticRegression(random_state=42)
        lr.fit(X_train, y_train)
        models['Logistic Regression'] = lr

    # Random Forest
    with st.spinner("Training Random Forest..."):
        rf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
        rf.fit(X_train, y_train)
        models['Random Forest'] = rf

    # XGBoost
    with st.spinner("Training XGBoost..."):
        xgb = XGBClassifier(random_state=42, use_label_encoder=False, eval_metric='logloss')
        xgb.fit(X_train, y_train)
        models['XGBoost'] = xgb

    # Isolation Forest (Unsupervised)
    with st.spinner("Training Isolation Forest..."):
        iso_forest = IsolationForest(contamination=0.0017, random_state=42)
        iso_forest.fit(X_train)
        models['Isolation Forest'] = iso_forest

    st.write("Model training complete.")
    return models


# 3. Real-Time Monitoring Simulation
def simulate_real_time_monitoring(df, model, model_name):
    if model_name == 'Isolation Forest':
        predictions = model.predict(df.drop(['Class'], axis=1))
        predictions = np.where(predictions == -1, 1, 0)  # -1 is anomaly (fraud)
    else:
        predictions = model.predict(df.drop(['Class'], axis=1))

    df['Prediction'] = predictions
    return df


# 4. Dashboard and Visualizations
def create_dashboard(df, models, X_test, y_test):
    st.title("Financial Fraud Detection Dashboard")

    # Model selector
    model_name = st.selectbox("Select Model", list(models.keys()))

    # Evaluate selected model
    st.subheader(f"Evaluation Metrics for {model_name}")
    if model_name == 'Isolation Forest':
        predictions = models[model_name].predict(X_test)
        predictions = np.where(predictions == -1, 1, 0)
    else:
        predictions = models[model_name].predict(X_test)
    report = classification_report(y_test, predictions, output_dict=True)
    st.write(pd.DataFrame(report).transpose())

    # Simulate real-time monitoring
    result_df = simulate_real_time_monitoring(df.copy(), models[model_name], model_name)

    # Fraud distribution plot
    st.subheader("Fraud vs Non-Fraud Distribution")
    fraud_counts = result_df['Prediction'].value_counts().reset_index()
    fraud_counts.columns = ['Prediction', 'Count']
    fraud_fig = px.bar(fraud_counts, x='Prediction', y='Count', title='Fraud vs Non-Fraud Distribution',
                       labels={'Prediction': 'Class (0: Non-Fraud, 1: Fraud)'})
    st.plotly_chart(fraud_fig)

    # Anomaly scores
    st.subheader("Anomaly Score Distribution")
    # Drop 'Class' and 'Prediction' only if they exist
    columns_to_drop = ['Class']
    if 'Prediction' in df.columns:
        columns_to_drop.append('Prediction')
    df_for_scores = df.drop(columns_to_drop, axis=1)

    if model_name == 'Isolation Forest':
        scores = models[model_name].decision_function(df_for_scores)
        scores = -scores  # Higher is more anomalous
    else:
        scores = models[model_name].predict_proba(df_for_scores)[:, 1]
    score_fig = px.histogram(x=scores, nbins=50, title='Anomaly Score Distribution')
    st.plotly_chart(score_fig)

    st.subheader("Feature Importance")

    if model_name in ['Random Forest', 'XGBoost']:
        model = models[model_name]
        if hasattr(model, 'feature_importances_'):
            importances = model.feature_importances_
            features = X_test.columns
            importance_df = pd.DataFrame({'Feature': features, 'Importance': importances})
            importance_df = importance_df.sort_values(by='Importance', ascending=False)

            fig = px.bar(importance_df, x='Importance', y='Feature', orientation='h',
                         title=f'Feature Importance for {model_name}',
                         labels={'Importance': 'Importance Score', 'Feature': 'Feature'})
            st.plotly_chart(fig)
        else:
            st.write("Feature importance not available for this model.")
    else:
        st.write("Feature importance is only available for Random Forest and XGBoost models.")


def main():
    # Load and preprocess data
    df = load_and_preprocess_data()
    if df is None:
        return

    # Split data
    X = df.drop('Class', axis=1)
    y = df['Class']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

    # Train models
    models = train_models(X_train, y_train)

    # Create dashboard
    create_dashboard(df, models, X_test, y_test)


if __name__ == '__main__':
    main()